<meta charset="utf8">
<a href="?nuist=upload">upload?</a>

<?php

include $_GET['nuist'].'.'.php
?>